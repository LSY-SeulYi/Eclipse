package ex23_imagedraw;
	
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;


public class Main extends Application {	// 무대 장식
	@Override
	public void start(Stage primaryStage) {
		try {
			// BorderPane => 컨테이너
			BorderPane root = new BorderPane();
			
			root.setCenter(new MyDrawPane(380,380));
			// Scene => 장면 (380,380 은 크기)
			Scene scene = new Scene(root,380,380);
			
			// 위에서 만든 장면을 무대에 세팅시킴
			primaryStage.setScene(scene);
			// 위에서 세팅 시킨 무대 장면을 보여줌
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
